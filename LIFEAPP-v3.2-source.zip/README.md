# LIFEAPP v3.2

Based on the verified LIFEAPP v3.1 restored native UI.

## v3.2 architecture
- Original `liblifeapp.so` retained unchanged as the stable visual/native engine.
- Java bridge (`LifeAppActivity`) added so new modules can evolve without binary patching.
- Profile context exposes Settings/Language.
- Explore context exposes LIFEAPP Music.
- Locale selector scaffold includes system language + 26 manual language choices and RTL support flag.
- Music hub scaffold includes Spotify, Apple Music, YouTube Music and Amazon Music provider slots.
- Version: 3.2.0 / code 320.

Provider authentication is intentionally not embedded in source or APK. Spotify credentials will be configured separately.
