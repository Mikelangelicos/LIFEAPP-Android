# LIFEAPP Android v3.1

Base visual restaurada desde LIFEAPP v2.5 original.

- applicationId: `app.lifeapp.mobile` (compatible con la instalación v3.0)
- versionCode: 310
- versionName: 3.1.0
- minSdk: 26
- targetSdk / compileSdk: 36
- interfaz nativa original: `liblifeapp.so`
- launcher icon original: `@mipmap/ic_launcher`
