plugins { id("com.android.application") }

android {
    namespace = "app.lifeapp.v250"
    compileSdk = 36
    defaultConfig {
        applicationId = "app.lifeapp.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 310
        versionName = "3.1.0"
    }
}
